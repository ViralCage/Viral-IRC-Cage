module.exports = {
    printWidth: 120,
    quoteProps: 'consistent',
    semi: true,
    singleQuote: true,
    trailingComma: 'es5',
    tabWidth: 4,
    jsdocVerticalAlignment: true,
};
